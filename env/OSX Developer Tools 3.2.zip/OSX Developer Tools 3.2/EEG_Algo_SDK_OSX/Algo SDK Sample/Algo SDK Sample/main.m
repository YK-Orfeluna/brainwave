//
//  main.m
//  Algo SDK Sample
//
//  Created by Donald on 6/7/15.
//  Copyright (c) 2015 NeuroSky. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
