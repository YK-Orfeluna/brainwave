//
//  AppDelegate.h
//  Algo SDK Sample
//
//  Created by Donald on 6/7/15.
//  Copyright (c) 2015 NeuroSky. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

