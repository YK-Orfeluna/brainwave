@interface CPTDecimalNumberValueTransformer : NSValueTransformer

@end
