#import "_CPTXYTheme.h"

@interface _CPTSlateTheme : _CPTXYTheme

@end
