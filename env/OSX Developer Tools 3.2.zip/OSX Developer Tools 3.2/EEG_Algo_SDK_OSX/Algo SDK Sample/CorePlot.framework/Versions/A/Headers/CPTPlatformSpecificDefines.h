/// @file

typedef NSImage CPTNativeImage; ///< Platform-native image format.
typedef NSEvent CPTNativeEvent; ///< Platform-native OS event.
