//
//  main.m
//  TGStreamMacDemo
//
//  Created by peterwang on 8/11/15.
//  Copyright (c) 2015 NeuroSky. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
